import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/steam_account.dart';

class ApiService {
  static const String baseUrl = 'http://192.168.88.13:5001';

  static Future<Map<String, dynamic>> getAccounts() async {
    final response = await http.get(Uri.parse('$baseUrl/api/accounts'));
    return json.decode(response.body);
  }

  static Future<Map<String, dynamic>> addAccount({
    required String login,
    required String password,
    required Map<String, dynamic> mafile,
    String? nickname,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/accounts'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'login': login,
        'password': password,
        'mafile': mafile,
        'nickname': nickname,
      }),
    );
    return json.decode(response.body);
  }

  static Future<Map<String, dynamic>> generateCode(int accountId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/accounts/$accountId/code'),
    );
    return json.decode(response.body);
  }

  static Future<Map<String, dynamic>> changePassword(
    int accountId, {
    String? newPassword,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/accounts/$accountId/password'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'new_password': newPassword}),
    );
    return json.decode(response.body);
  }

  static Future<Map<String, dynamic>> setAutoChange(
    int accountId, {
    required bool enabled,
    required int intervalHours,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/accounts/$accountId/auto-change'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'enabled': enabled,
        'interval_hours': intervalHours,
      }),
    );
    return json.decode(response.body);
  }

  static Future<Map<String, dynamic>> deleteAccount(int accountId) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/api/accounts/$accountId'),
    );
    return json.decode(response.body);
  }
}